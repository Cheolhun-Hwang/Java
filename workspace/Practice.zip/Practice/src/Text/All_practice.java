/**
 * 파일명 : All_practice.java
 * 작성일 : 2016. 7. 27.
 * 파일설명 :
 */
package Text;

/*import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;*/
import java.io.*;

//////////////////////////저장 및 sql 삽입을 위한 클래스/////////////////
class Table_cul{
	private String where;
	private int when;
	private String withwho;
	private String point_where;
	
	Table_cul(){
		this.where = "";
		this.when = 0;
		this.withwho = "";
		this.point_where = "";
	};
	
	public void insert_sql(Table_cul tc){
		
	}
}
////////////////////////////////////////////////////////////
///////////////////////디렉토리에서 파일을 읽기 위한 클라스/////////////////////
public class All_practice {
	
	public void subDirList(String source) {
		// TODO Auto-generated method stub
		File dir=new File(source);
		File[] FileList=dir.listFiles();
		try{
			for(int i = 0; i<FileList.length;i++){
				File file = FileList[i];
				if(file.isFile()){
					//파일이 존재한다면 읽는다.
					System.out.println("\t파일이름 = "+file.getName());
					try {
						String file_url = source + file.getName();
						FileInputStream fin = new FileInputStream(file_url);
						InputStreamReader inreader = new InputStreamReader(fin, "utf-8");
						BufferedReader breader = new BufferedReader(inreader);
						//int s;
						String s;
						while((s =/*inreader.read()*/ breader.readLine()) != /*-1*/ null){
							System.out.println(/*(char)*/s);
							//이부분이  파일 내용을 반복해서 문장으로 읽어들이는 부분입니다.
						}
					
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch(IOException e){
						e.printStackTrace();
					}
					
					
					
				}else if(file.isDirectory()){
					System.out.println("디렉토리 이름 = "+file.getName());
					//서브디렉토리가 존재하면 재귀적 방법으로 다시 탐색
					//subDirList(file.getCanonicalPath().toString());
				}
			}
		}catch(/*IO*/Exception e){
			System.out.println("에러!!");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		All_practice sdf = new All_practice();
		String source = "C:\\Users\\qewqs\\Desktop\\exam_txt\\";
		sdf.subDirList(source);
		
		
	}

}
//////////////////////////////////////////////////////////////////////////